
public class QueueEmptyException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7243921724361015813L;

}
