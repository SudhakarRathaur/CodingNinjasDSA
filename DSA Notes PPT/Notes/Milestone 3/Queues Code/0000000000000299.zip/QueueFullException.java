
public class QueueFullException  extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = -7167634756637168192L;

}
